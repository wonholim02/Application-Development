package com.g55.myapplication.model;

import junit.framework.TestCase;

public class LandObstacleTest extends TestCase {

}